const balances = { USD: 10000, BTC: 0.5, ETH: 1.2, CGK: 1000 };
const ul = document.getElementById("balances");
for (let coin in balances) {
  const li = document.createElement("li");
  li.textContent = `${coin}: ${balances[coin]}`;
  ul.appendChild(li);
}
