let balance = { USD: 10000, BTC: 0, ETH: 0, CGK: 0 };
const prices = { BTC: 69000, ETH: 3500, CGK: 0.123 };

function updateUI() {
  const ul = document.getElementById("tradeBalances");
  ul.innerHTML = "";
  for (let coin in balance) {
    const li = document.createElement("li");
    li.textContent = `${coin}: ${balance[coin].toFixed(4)}`;
    ul.appendChild(li);
  }
}

function buy() {
  const coin = document.getElementById("coinSelect").value;
  const amt = parseFloat(document.getElementById("amountInput").value);
  if (amt * prices[coin] <= balance.USD) {
    balance.USD -= amt * prices[coin];
    balance[coin] += amt;
    updateUI();
  } else {
    alert("Not enough USD");
  }
}

function sell() {
  const coin = document.getElementById("coinSelect").value;
  const amt = parseFloat(document.getElementById("amountInput").value);
  if (balance[coin] >= amt) {
    balance.USD += amt * prices[coin];
    balance[coin] -= amt;
    updateUI();
  } else {
    alert("Not enough coin");
  }
}

updateUI();
